
export enum Tab {
  Review = 'Code Review',
  Security = 'Security Audit',
  Tests = 'Unit Tests',
}

export interface ReviewResults {
  [Tab.Review]: string;
  [Tab.Security]: string;
  [Tab.Tests]: string;
}
