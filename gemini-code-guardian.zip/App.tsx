
import React, { useState, useCallback } from 'react';
import { CodeInput } from './components/CodeInput';
import { ReviewTabs } from './components/ReviewTabs';
import { ReviewPanel } from './components/ReviewPanel';
import { Loader } from './components/Loader';
import { ErrorMessage } from './components/ErrorMessage';
import { getAiFeedback } from './services/geminiService';
import { ReviewResults, Tab } from './types';

const App: React.FC = () => {
  const [code, setCode] = useState<string>('');
  const [language, setLanguage] = useState<string>('javascript');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<ReviewResults | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Review);

  const handleReview = useCallback(async () => {
    if (!code.trim()) {
      setError('Please enter some code to review.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResults(null);

    try {
      const feedback = await getAiFeedback(code, language);
      setResults(feedback);
      setActiveTab(Tab.Review);
    } catch (err) {
      console.error(err);
      setError('An error occurred while fetching the review. Please check your API key and try again.');
    } finally {
      setIsLoading(false);
    }
  }, [code, language]);

  return (
    <div className="min-h-screen bg-brand-primary font-sans">
      <header className="bg-brand-secondary p-4 shadow-md">
        <div className="container mx-auto flex items-center gap-4">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-brand-accent">
            <path fillRule="evenodd" d="M9.401 3.003c1.155.63 2.563.262 3.37-.813a.75.75 0 011.26.791 10.45 10.45 0 01-2.903 5.22c-1.353 1.485-3.15 2.401-5.126 2.401a.75.75 0 010-1.5c1.68 0 3.24-.75 4.4-1.956A9.006 9.006 0 0012 3.64a.75.75 0 01.599-.916.75.75 0 01.916.599 7.502 7.502 0 01-2.312 4.025.75.75 0 01-1.12-.224c-.42-.712-.42-1.612 0-2.324a.75.75 0 01.813-.398z" clipRule="evenodd" />
            <path d="M3 8.625c0-1.036.84-1.875 1.875-1.875h.375a.75.75 0 010 1.5h-.375a.375.375 0 00-.375.375v6.75a.375.375 0 00.375.375h6.75a.375.375 0 00.375-.375v-2.625a.75.75 0 011.5 0v2.625c0 1.035-.84 1.875-1.875 1.875h-6.75A1.875 1.875 0 013 15.375v-6.75z" />
            <path d="M14.25 5.25a.75.75 0 01.75-.75h5.25a.75.75 0 01.75.75v5.25a.75.75 0 01-1.5 0V6h-4.5a.75.75 0 01-.75-.75z" />
          </svg>
          <h1 className="text-2xl font-bold text-brand-text">Gemini Code Guardian</h1>
        </div>
      </header>
      <main className="container mx-auto p-4 md:p-8">
        <div className="bg-brand-secondary rounded-lg shadow-xl p-6 space-y-6">
          <h2 className="text-xl font-semibold text-brand-text">Submit Your Code for Analysis</h2>
          <CodeInput
            code={code}
            setCode={setCode}
            language={language}
            setLanguage={setLanguage}
            onReview={handleReview}
            isLoading={isLoading}
          />
          {error && <ErrorMessage message={error} />}
        </div>
        
        {isLoading && <Loader />}
        
        {results && !isLoading && (
          <div className="mt-8 bg-brand-secondary rounded-lg shadow-xl overflow-hidden">
            <ReviewTabs activeTab={activeTab} setActiveTab={setActiveTab} />
            <ReviewPanel content={results[activeTab]} />
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
