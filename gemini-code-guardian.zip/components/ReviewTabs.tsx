
import React from 'react';
import { Tab } from '../types';

interface ReviewTabsProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const TABS = [Tab.Review, Tab.Security, Tab.Tests];

export const ReviewTabs: React.FC<ReviewTabsProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="border-b border-gray-700">
      <nav className="-mb-px flex space-x-4 px-6" aria-label="Tabs">
        {TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`
              whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${
                activeTab === tab
                  ? 'border-brand-accent text-brand-accent'
                  : 'border-transparent text-brand-subtle hover:text-brand-text hover:border-gray-500'
              }
              focus:outline-none transition-colors
            `}
            aria-current={activeTab === tab ? 'page' : undefined}
          >
            {tab}
          </button>
        ))}
      </nav>
    </div>
  );
};
