
import React from 'react';
import { CodeBlock } from './CodeBlock';

interface ReviewPanelProps {
  content: string;
}

// A very basic component to render markdown-like content from Gemini
const MarkdownRenderer: React.FC<{ text: string }> = ({ text }) => {
  const parts = text.split(/(\`\`\`[\s\S]*?\`\`\`)/g);

  return (
    <>
      {parts.map((part, index) => {
        if (part.startsWith('```') && part.endsWith('```')) {
          const codeContent = part.replace(/```[a-zA-Z]*\n?/, '').replace(/```$/, '');
          return <CodeBlock key={index} code={codeContent.trim()} />;
        }
        
        // Render other text with basic formatting
        return (
          <div key={index} className="prose prose-invert prose-sm sm:prose-base max-w-none">
            {part.split('\n').map((line, lineIndex) => {
              if (line.startsWith('### ')) {
                return <h3 key={lineIndex} className="font-semibold text-lg mt-4 mb-2">{line.substring(4)}</h3>;
              }
              if (line.startsWith('## ')) {
                return <h2 key={lineIndex} className="font-bold text-xl mt-6 mb-3 border-b border-gray-700 pb-2">{line.substring(3)}</h2>;
              }
              if (line.startsWith('# ')) {
                return <h1 key={lineIndex} className="font-extrabold text-2xl mt-8 mb-4 border-b border-gray-600 pb-2">{line.substring(2)}</h1>;
              }
              if (line.startsWith('* ')) {
                return <li key={lineIndex} className="ml-4 list-disc">{line.substring(2)}</li>
              }
               if (line.trim() === '---') {
                return <hr key={lineIndex} className="my-6 border-gray-700" />;
              }
              return <p key={lineIndex}>{line}</p>;
            })}
          </div>
        );
      })}
    </>
  );
};


export const ReviewPanel: React.FC<ReviewPanelProps> = ({ content }) => {
  return (
    <div className="p-6 text-brand-text">
      <MarkdownRenderer text={content} />
    </div>
  );
};
