
import React from 'react';

interface CodeInputProps {
  code: string;
  setCode: (code: string) => void;
  language: string;
  setLanguage: (language: string) => void;
  onReview: () => void;
  isLoading: boolean;
}

const LANGUAGES = [
  'javascript',
  'typescript',
  'python',
  'java',
  'csharp',
  'cpp',
  'go',
  'rust',
  'html',
  'css'
];

export const CodeInput: React.FC<CodeInputProps> = ({ code, setCode, language, setLanguage, onReview, isLoading }) => {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="w-full sm:w-64">
          <label htmlFor="language-select" className="block text-sm font-medium text-brand-subtle mb-1">
            Language
          </label>
          <select
            id="language-select"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="w-full bg-brand-primary border border-gray-600 rounded-md shadow-sm p-2.5 focus:ring-2 focus:ring-brand-accent focus:border-brand-accent text-brand-text"
          >
            {LANGUAGES.map((lang) => (
              <option key={lang} value={lang} className="capitalize">
                {lang.charAt(0).toUpperCase() + lang.slice(1)}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div>
        <label htmlFor="code-input" className="block text-sm font-medium text-brand-subtle mb-1">
          Code
        </label>
        <textarea
          id="code-input"
          rows={15}
          className="w-full bg-brand-primary border border-gray-600 rounded-md shadow-sm p-4 font-mono text-sm focus:ring-2 focus:ring-brand-accent focus:border-brand-accent text-brand-text resize-y"
          placeholder="Paste your code here..."
          value={code}
          onChange={(e) => setCode(e.target.value)}
        />
      </div>
      <div className="flex justify-end">
        <button
          onClick={onReview}
          disabled={isLoading}
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-accent hover:bg-brand-accent-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-secondary focus:ring-brand-accent disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing...
            </>
          ) : (
            'Review Code'
          )}
        </button>
      </div>
    </div>
  );
};
