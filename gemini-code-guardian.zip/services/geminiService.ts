
import { GoogleGenAI } from "@google/genai";
import type { ReviewResults } from '../types';
import { Tab } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const model = ai.models;

const generateReview = async (code: string, language: string): Promise<string> => {
  const prompt = `
    As an expert senior software engineer, conduct a thorough code review of the following ${language} code.
    Focus on:
    - Best practices and code clarity
    - Readability and maintainability
    - Potential bugs and logical errors
    - Performance optimizations
    - Adherence to language conventions

    Provide clear, actionable feedback with code snippets where helpful. Structure your review with headings.

    Code to review:
    \`\`\`${language}
    ${code}
    \`\`\`
    `;

  try {
    const response = await model.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating code review:", error);
    return "Failed to generate code review.";
  }
};

const generateSecurityAudit = async (code: string, language: string): Promise<string> => {
  const prompt = `
    As a cybersecurity expert, analyze the following ${language} code for security vulnerabilities.
    Check for common issues such as:
    - Injection attacks (SQL, Command Injection, etc.)
    - Cross-Site Scripting (XSS)
    - Insecure Deserialization
    - Sensitive Data Exposure
    - Authentication/Authorization flaws
    - Insecure direct object references

    For each vulnerability found, explain the risk and provide a clear, corrected code snippet to fix it. If no issues are found, state that.

    Code to analyze:
    \`\`\`${language}
    ${code}
    \`\`\`
    `;
    
  try {
    const response = await model.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating security audit:", error);
    return "Failed to generate security audit.";
  }
};

const generateUnitTests = async (code: string, language: string): Promise<string> => {
  const popularFrameworks: { [key: string]: string } = {
    javascript: 'Jest',
    typescript: 'Jest with ts-jest',
    python: 'pytest',
    java: 'JUnit 5',
    csharp: 'xUnit or MSTest',
    go: 'Go\'s built-in testing package',
    rust: 'Rust\'s built-in test framework'
  };
  const framework = popularFrameworks[language] || 'a popular testing framework for that language';

  const prompt = `
    As a software quality engineer, write a comprehensive suite of unit tests for the following ${language} code using ${framework}.
    The tests should cover:
    - Happy paths (correct inputs and expected outputs)
    - Edge cases (empty values, nulls, boundaries)
    - Error handling (invalid inputs, exceptions)

    Provide the complete, runnable code for the tests inside a single markdown code block.

    Code to test:
    \`\`\`${language}
    ${code}
    \`\`\`
    `;

  try {
    const response = await model.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating unit tests:", error);
    return "Failed to generate unit tests.";
  }
};


export const getAiFeedback = async (code: string, language: string): Promise<ReviewResults> => {
  const [review, security, tests] = await Promise.all([
    generateReview(code, language),
    generateSecurityAudit(code, language),
    generateUnitTests(code, language),
  ]);

  return {
    [Tab.Review]: review,
    [Tab.Security]: security,
    [Tab.Tests]: tests,
  };
};
